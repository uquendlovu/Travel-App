# IonicTravelAppEp4
### Ionic 5+ Travel App 2021 | Part 4 - App Landing Page | Using Swiper JS (Alternative of ion-slides)

Watch the Full Episode on YouTube at https://youtu.be/ZQtZX63IPuA

Ionic 5+Travel App Series: https://www.youtube.com/playlist?list=PLixvNT19uDK54YjJgmEqEsN-IlhaHSASS

<img src="https://github.com/Nykz/IonicTravelAppEp4/blob/main/travel4%20thumbnail.png" width="1000" height="600" />
