# Ionic Firebase File Upload
 Ionic Firebase - File Upload/Transfer to Cloud Storage | Angular

Watch full episode at https://youtu.be/ND-xs_fEWIM
