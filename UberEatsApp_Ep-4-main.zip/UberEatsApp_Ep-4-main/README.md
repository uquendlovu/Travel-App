# UberEatsApp_Ep-4
### Ionic 6 Uber-Eats App - Episode 4

Watch the Full Episode on YouTube at https://youtu.be/-5zHsN-d-do

Ionic 6 Uber eats app complete series: https://www.youtube.com/playlist?list=PLixvNT19uDK6KvCAXMWtsS3EiwXZI8xwJ

<img src="https://github.com/Nykz/UberEatsApp_Ep-4/blob/main/Snapshot.png" width="1200" height="600" />

### Steps to Setup this App in your system

1.Watch the series 

2.Follow step by step guide in video to setup firebase & create the same app

That's it
