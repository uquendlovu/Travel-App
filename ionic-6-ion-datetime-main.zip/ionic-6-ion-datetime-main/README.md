# ionic 6 ion-datetime
 ### Ionic 6 dynamic ion-datetime with shared component

Watch the Full Episode on YouTube at https://youtu.be/ohOa5yrfYy0

Ionic 6 Uber Eats App Series: https://www.youtube.com/watch?v=Td46HaHVR0g&list=PLixvNT19uDK6KvCAXMWtsS3EiwXZI8xwJ&ab_channel=CodingTechnyks

<img src="https://github.com/Nykz/ionic-6-ion-datetime/blob/main/Snapshot_43.png" width="1200" height="500" />
