# Uber-eats-app-ep7
### Ionic 6+ Uber eats app series - Search page UI - Episode 7

Watch the Full Episode on YouTube at https://www.youtube.com/watch?v=yXp7Z-6BbA8&list=PLixvNT19uDK6KvCAXMWtsS3EiwXZI8xwJ&index=7&ab_channel=CodingTechnyks

Ionic 6 Uber Eats App Series: https://www.youtube.com/watch?v=Td46HaHVR0g&list=PLixvNT19uDK6KvCAXMWtsS3EiwXZI8xwJ&ab_channel=CodingTechnyks

<img src="https://github.com/Nykz/Uber-eats-app-ep7/blob/main/images/Snapshot_30.png" width="1000" height="600" />
