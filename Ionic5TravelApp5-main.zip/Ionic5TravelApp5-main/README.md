# Ionic5TravelApp5
Ionic 5+ Travel App 2021 | Part 5 - Single Trip Screen (Get trip ID from routing for dynamic data)

Watch the Full Episode on YouTube at https://youtu.be/UCppd0YqK8M

Ionic 5+Travel App Series: https://www.youtube.com/playlist?list=PLixvNT19uDK54YjJgmEqEsN-IlhaHSASS

<img src="https://github.com/Nykz/Ionic5TravelApp5/blob/main/travel5%20thumbnail.png" width="1000" height="600" />
